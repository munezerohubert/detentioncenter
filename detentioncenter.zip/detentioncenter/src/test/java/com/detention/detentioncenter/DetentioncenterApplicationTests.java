package com.detention.detentioncenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DetentioncenterApplicationTests {

    @Test
    void contextLoads() {
    }

}
