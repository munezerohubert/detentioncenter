package com.detention.detentioncenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetentioncenterApplication {

    public static void main(String[] args) {
        SpringApplication.run(DetentioncenterApplication.class, args);
    }

}
