package com.detention.detentioncenter.user;

import jakarta.persistence.*;

@Entity
@Table(name ="users")
public class user {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
@Column(nullable = false, unique = true,length = 50, name = "first_name")
    private String fname;
    @Column(nullable = false, unique = true,length = 50, name = "last_name")
    private String lname;
    @Column(nullable = false, unique = true,length = 50, name = "crime")
    private String crime;
    @Column(nullable = false, unique = true,length = 50,name = "crime_description")
    private String descrption;
    @Column(nullable = false, unique = true,length = 50,name = "photo")
    private Byte[] photo;
    
}
